part of 'animation_bloc.dart';

@immutable
sealed class AnimationState {}

final class AnimationInitial extends AnimationState {}
