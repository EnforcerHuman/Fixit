part of 'animation_bloc.dart';

@immutable
sealed class AnimationEvent {}
