class MainNavigationState {
  final int selectedIndex;
  MainNavigationState(this.selectedIndex);
}
