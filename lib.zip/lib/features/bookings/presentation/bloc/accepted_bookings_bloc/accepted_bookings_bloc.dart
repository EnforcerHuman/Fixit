import 'package:bloc/bloc.dart';
import 'package:fixit/features/bookings/data/model/booking_model.dart';
import 'package:fixit/features/bookings/domain/use_cases/booking_use_case.dart';
import 'package:meta/meta.dart';

part 'accepted_bookings_event.dart';
part 'accepted_bookings_state.dart';

class AcceptedBookingsBloc
    extends Bloc<AcceptedBookingsEvent, AcceptedBookingsState> {
  final BookingUseCase bookingUseCase;
  AcceptedBookingsBloc(this.bookingUseCase) : super(AcceptedBookingsInitial()) {
    on<AcceptedBookingsEvent>((event, emit) {
      // TODO: implement event handler
    });
    on<GetAccceptedBooking>((event, emit) async {
      try {
        await emit.forEach<List<BookingModel>>(
          bookingUseCase.getAcceptedBooking(),
          onData: (data) {
            // Print each booking in the received list
            data.forEach((booking) {
              print('Accepted Booking: $booking');
            });
            return AcceptedBookingLoaded(data);
          },
          onError: (error, stackTrace) {
            print('Error: $error');
            return AcceptedBookingError();
          },
        );
      } catch (e) {
        print('Catch block error: $e');
        emit(AcceptedBookingError());
      }
    });
  }
}
