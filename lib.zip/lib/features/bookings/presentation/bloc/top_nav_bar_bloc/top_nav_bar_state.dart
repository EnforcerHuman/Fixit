part of 'top_nav_bar_bloc.dart';

@immutable
// sealed class TopNavBarState {}

class TopNavState {
  final int selectedIndex;

  TopNavState(this.selectedIndex);
}
