import 'package:fixit/features/bookings/presentation/bloc/accepted_bookings_bloc/accepted_bookings_bloc.dart';
import 'package:fixit/features/bookings/presentation/widgets/booking_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class UpcomingBookingsScreen extends StatelessWidget {
  const UpcomingBookingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    context.read<AcceptedBookingsBloc>().add(GetAccceptedBooking());
    return Scaffold(
        body: BlocBuilder<AcceptedBookingsBloc, AcceptedBookingsState>(
      builder: (context, state) {
        print(state);

        if (state is AcceptedBookingLoaded) {
          print(state.acceptedBookings[0].serviceId);
          return ListView.builder(
              itemCount: state.acceptedBookings.length,
              itemBuilder: (context, index) {
                final booking = state.acceptedBookings[index];
                return Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: BookingCard(
                      service: booking.serviceName,
                      amount: 300, // Update this as necessary
                      bookingDate: booking.bookingDateTime ?? 'No Date',
                      partnerName: booking.serviceName ?? 'No Provider'),
                );
              });
        } else if (state is AcceptedBookingError) {
          return Center(child: Text('Error: '));
        } else {
          return const Center(child: CircularProgressIndicator());
        }
      },
    ));
  }
}
