import 'package:fixit/features/bookings/data/data_source/booking_remote_data_source.dart';
import 'package:fixit/features/bookings/data/model/booking_model.dart';

class BookingUseCase {
  BookingRemotedataSource bookingRemotedataSource = BookingRemotedataSource();
  Stream<List<BookingModel>> getPendingBooking() {
    return bookingRemotedataSource.getBookings().map((bookings) {
      print(bookings);
      return bookings
          .where((booking) => booking.status == 'Requested')
          .toList();
    });
  }

  Stream<List<BookingModel>> getAcceptedBooking() {
    return bookingRemotedataSource.getBookings().map((bookings) {
      return bookings.where((booking) => booking.status == 'Accepted').toList();
    });
  }

  Stream<List<BookingModel>> getRejectedBookings() {
    return bookingRemotedataSource.getBookings().map((bookings) {
      return bookings.where((booking) => booking.status == 'Rejected').toList();
    });
  }
}
