class ProviderListingScreeUseCases {
  void onSearchSkilledWorkers() {}
}
