List<Map<String, String>> pageArr = [
  {
    "title": 'Beauty Parlour at your home',
    "subtitle":
        "Don't worry if you need Beauty parlour at home,we are there for you",
    "image": "assets/img/onboarding_1.png"
  },
  {
    "title": 'Plumber & Expart near you',
    "subtitle":
        "Let's keep burning to achieve your goals. It hurts only temporarily. If you give up now, you will be in pain forever",
    "image": "assets/img/onboarding_2.png"
  },
  {
    "title": 'Professional home cleaning',
    "subtitle":
        "Let's start a healthy lifestyle with us. We can determine your diet every day. Healthy eating is fun",
    "image": "assets/img/onboarding_3.jpg"
  },
];
